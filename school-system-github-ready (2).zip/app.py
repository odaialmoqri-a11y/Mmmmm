from flask import Flask, send_from_directory
import sqlite3
from flask_cors import CORS
import os

app = Flask(__name__, static_url_path='', static_folder='.')
CORS(app)

# ✅ فتح قاعدة البيانات
def get_db_connection():
    conn = sqlite3.connect('school.db')
    conn.row_factory = sqlite3.Row
    return conn

# ✅ الصفحة الرئيسية
@app.route('/')
def index():
    return send_from_directory('.', 'school.html')

# ✅ مثال على API (تجيب الطلاب)
@app.route('/api/students')
def students():
    conn = get_db_connection()
    students = conn.execute('SELECT * FROM students').fetchall()
    conn.close()
    return [dict(row) for row in students]

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
